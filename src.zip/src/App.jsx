
import './App.css'
import { Home } from './components/Home'
import {Routes,Route} from "react-router-dom"
import { BasicModal } from './components/Box'
function App() {
 
  return (
    <div className="App">
    
    <Routes>
       <Route path={"/"} element={<Home></Home>}></Route> 
    </Routes>
    </div>
  )
}

export default App
