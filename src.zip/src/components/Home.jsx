import { useEffect, useState } from "react"
import { BasicModal } from "./Box"
import InfiniteScroll from "react-infinite-scroll-component";

export const Home=()=>{
    const [data,setData]=useState([])
    const [page,setPage]=useState(1)
    const [name,setName]=useState("rick")
    const [count,setcount]=useState(20)
    useEffect(()=>{
    Getdata()
    },[name])

    const Getdata=async() =>{
        console.log(name)
        try{
            if(page!==1){
                setPage(page+1)
                let Data= await fetch(`https://rickandmortyapi.com/api/character/?name=${name}&page=${page}`);
                let FetchData=await Data.json()
            setData(FetchData.results)
            setcount(FetchData.info.count)
            console.log(FetchData)
            }
            else{
            let Data= await fetch(`https://rickandmortyapi.com/api/character/?name=${name}&page=${page}`);
            let FetchData=await Data.json()
            setData(FetchData.results)
            setcount(FetchData.info.count)
            console.log(FetchData)}
        }
        catch(error){
            console.log(error)
        }

     }  

return (
    <div>
    <input placeholder="name" type="text" onInput={(e)=>{setName(e.target.value)}}></input>
    <InfiniteScroll
            dataLength={count}
            next={Getdata}
            hasMore={true}
            loader={<h4>Loading...</h4>}
            scrollableTarget="scrollableDiv"
          >
        {data.map((e)=>{
            return (
              
                <div key={e.id} >
                <div><BasicModal  prop={e}/></div>
                    <div>
                    <img src={e.image}></img>
                        <p>{e.name}</p>
                        <p>{e.status}</p>
                        <p>{e.species}</p>
                        <hr></hr>
                    </div>
                </div>
            )
        })}
      </InfiniteScroll>
      
    </div>
)

}